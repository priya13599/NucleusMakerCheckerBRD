package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.nucleus.dao.CustomerRDBMSImplService;
import com.nucleus.dao.ICustomerService;
import com.nucleus.entity.Customer;
import com.nucleus.validation.CheckValidations;
import com.nucleus.validation.ValidationMethods;

/**
 * Servlet implementation class CustomerController
 */
@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet {
	
	
	
	private static final long serialVersionUID = 1L;
	static Logger log = Logger.getLogger(com.nucleus.controller.CustomerController.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerController() {
        super();
      
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter writer = response.getWriter();
		
		String button = request.getParameter("button");
	
		if(button.equals("Insert"))
		{
		
		boolean j=false;
		ValidationMethods validationmethods = new ValidationMethods();                             // Object of ValidationMethods class
		CheckValidations checkvalidationmethods = new CheckValidations(); 
		
		ICustomerService customerservice = new CustomerRDBMSImplService();
		HttpSession session = request.getSession(false);
		String userid = (String) session.getAttribute("userid");
		//String userid="Priya12";
		String customercode = request.getParameter("customercode");
		String customername= request.getParameter("customername");
		String address1 = request.getParameter("address1");
		String address2 = request.getParameter("address2");
		int pincode = Integer.parseInt(request.getParameter("pincode"));
		String email = request.getParameter("email");
		long contactno = Long.parseLong(request.getParameter("contactno"));
		String contactperson = request.getParameter("contactperson");
		String flag = request.getParameter("flag");
		String recordstatus ="N";
		
		
		
		Customer customer = new Customer();
		customer.setCustomercode(customercode);
		customer.setCustomername(customername);
		customer.setAddress1(address1);
		customer.setAddress2(address2);
		customer.setCustomerpincode(pincode);
		customer.setEmailaddress(email);
		customer.setContactno(contactno);
		customer.setRecord_status(recordstatus);
		customer.setPrimary_contact_person(contactperson);
		customer.setActive_inactive_flag(flag);
		Date date = new Date();
		SimpleDateFormat smd = new SimpleDateFormat("dd/MMM/yyyy");
		
		String createdate = smd.format(date);
		try {
			customer.setCreate_date(new SimpleDateFormat("dd/MMM/yyyy").parse(createdate));
		} catch (ParseException e1) {
			log.error("Date Related error in SaveCustomerDetails method");
		}
		customer.setCreated_by(userid);
		
		
		 boolean b = validationmethods.CheckCustomerName(customer.getCustomername());
         boolean c2 = validationmethods.CheckEmailAddress(customer.getEmailaddress());
         boolean d = validationmethods.CheckPincode(Integer.toString(customer.getCustomerpincode()));
         boolean e = validationmethods.CheckRecordStatus(customer.getRecord_status());
         boolean f = validationmethods.CheckFlag(customer.getActive_inactive_flag());
         boolean g = checkvalidationmethods.DataLength(customer);
         boolean h = checkvalidationmethods.MandatoryFields(customer);     
         boolean i = checkvalidationmethods.DataType(customer);   
        try {
			ArrayList<Customer> list =  customerservice.CheckPrimaryKey();
			j = validationmethods.CheckPrimaryKey(list,customer.getCustomercode());
		} catch (SQLException e2) {
			log.error("Check Primary Key throws a SQL Exception");
		}
        
         if(b==true||c2==false||d == true||e==false||f ==false||g==false||h==false||i==false||j==true)
         {
        	 
        	 RequestDispatcher dispacher = request.getRequestDispatcher("ValidationFailed.jsp");
        	 dispacher.forward(request, response);
        	 
         }
         else
         {
		
		try {
			
			customerservice.SaveCustomerDetails(customer);
			log.info("SaveCustomerDetails method Called");
			RequestDispatcher dispacher = request.getRequestDispatcher("SuccessInsertCustomerDetails.jsp");
       	 dispacher.forward(request, response);
		
		} catch (SQLException e1) {
			log.error("SaveCustomerDetails method throws a SQL Exception");
			
		}
		
         }
		
		}
		
		else if(button.equals("Delete"))
		{
			
			String customercode = request.getParameter("customercode");
			Customer customer = new Customer();
			HttpSession session = request.getSession(false);
			
			ICustomerService customerservice = new CustomerRDBMSImplService();
			customer.setCustomercode(customercode);
			try {
				
				customerservice.DeleteCustomerDetails(customer);
				log.info("DeleteCustomerDetails method Called");
				RequestDispatcher dispacher = request.getRequestDispatcher("SuccessDeleteCustomerDetails.jsp");
				dispacher.forward(request, response);
			} catch (SQLException e) {
				
				log.error("DeleteCustomerDetails method throws a SQL Exception");
			}
		
		}
		

		else if(button.equals("Display"))
		{
			ICustomerService customerservice = new CustomerRDBMSImplService();
			HttpSession session = request.getSession(false);
		try {
			ArrayList<Customer> customerlist = customerservice.DisplayCustomerDetails();
			log.info("DisplayCustomerDetails Method Called");
			session.setAttribute("sn","sn1");
			session.setAttribute("customerlist", customerlist);
			RequestDispatcher dispacher = request.getRequestDispatcher("DisplayCustomerDetails.jsp");
	//RequestDispatcher dispacher = request.getRequestDispatcher("DatatableNew.jsp");
			dispacher.forward(request,response);
		} catch (SQLException e) {
			log.error("DisplayCustomerDetails method throws a SQL Exception");
		}
		}
		
		else if(button.equals("DisplayDatatable"))
		{
			ICustomerService customerservice = new CustomerRDBMSImplService();
			HttpSession session = request.getSession(false);
		try {
			ArrayList<Customer> customerlist = customerservice.DisplayCustomerDetails();
			log.info("DisplayCustomerDetails Method Called");
			session.setAttribute("sn","sn1");
			session.setAttribute("customerlist", customerlist);	
	RequestDispatcher dispacher = request.getRequestDispatcher("DatatableNew.jsp");
			dispacher.forward(request,response);
		} catch (SQLException e) {
			log.error("DisplayCustomerDetails method throws a SQL Exception");
		}
		}
		
		else if(button.equals("DisplayDetails"))
		{
			String customercode=request.getParameter("customercode");
			ICustomerService customerservice = new CustomerRDBMSImplService();
			HttpSession session = request.getSession(false);
			
			try {
				Customer customer = customerservice.DispalyCustomerDetailsByCode(customercode);
				log.info("DispalyCustomerDetailsByCode Method Called");
				session.setAttribute("sn","sn2");
				session.setAttribute("customer", customer);
				RequestDispatcher dispacher = request.getRequestDispatcher("DisplayCustomerDetails.jsp");
				
				dispacher.forward(request,response);
			} catch (SQLException e) {
			log.error("DisplayCustomerDetailsByCode method throws a SQL Exception");
			}
			
		}
		
		else if(button.equals("DisplayDetailsDatatable"))
		{
			String customercode=request.getParameter("customercode");
			ICustomerService customerservice = new CustomerRDBMSImplService();
			HttpSession session = request.getSession(false);
			System.out.println("hhs");
			try {
				Customer customer = customerservice.DispalyCustomerDetailsByCode(customercode);
				log.info("DispalyCustomerDetailsByCode Method Called");
				session.setAttribute("sn","sn2");
				session.setAttribute("customer", customer);
				
				RequestDispatcher dispacher = request.getRequestDispatcher("DatatableNew.jsp");
				dispacher.forward(request,response);
			} catch (SQLException e) {
			log.error("DisplayCustomerDetailsByCode method throws a SQL Exception");
			}
			
		}
		else if(button.equals("1"))
		{
			ICustomerService customerservice = new CustomerRDBMSImplService();
			HttpSession session = request.getSession(false);
			
			try {
				ArrayList<Customer> customerlist = customerservice.SortAscendingCustomerDetails();
				log.info("SortAscendingCustomerDetails Method Called");
				session.setAttribute("sn","sn1");
				session.setAttribute("customerlist", customerlist);
				RequestDispatcher dispacher = request.getRequestDispatcher("SortCustomerDetails.jsp");
				dispacher.forward(request,response);
			} catch (SQLException e) {
				log.error("SortAscendingCustomerDetails method throws a SQL Exception");
			}
			
			
		
		}
		
		
		else if(button.equals("2"))
		{
			ICustomerService customerservice = new CustomerRDBMSImplService();
			HttpSession session = request.getSession(false);
			try {
				ArrayList<Customer> customerlist = customerservice.SortDescendingCustomerDetails();
				log.info("SortDescendingCustomerDetails Method Called");
				session.setAttribute("sn","sn2");
				session.setAttribute("customerlist", customerlist);
				RequestDispatcher dispacher = request.getRequestDispatcher("SortCustomerDetails.jsp");
				dispacher.forward(request,response);
			} catch (SQLException e) {
				log.error("SortDescendingCustomerDetails method throws a SQL Exception");
			}
		}
		
		
		
		else if(button.equals("Update"))
		{
			
			String customercode = request.getParameter("customercode");
			
			ICustomerService customerservice = new CustomerRDBMSImplService();
			try {
				Customer customer =customerservice.updatecustomerDetails(customercode);
				log.info("updatecustomerDetails Method Called");
				HttpSession session = request.getSession(false);
				session.setAttribute("customercode",customer.getCustomercode());
				session.setAttribute("customername",customer.getCustomername());
				session.setAttribute("address1",customer.getAddress1());
				session.setAttribute("address2", customer.getAddress2());
				session.setAttribute("pincode",customer.getCustomerpincode());
				session.setAttribute("email",customer.getEmailaddress());
				session.setAttribute("contactno",customer.getContactno());
				session.setAttribute("status",customer.getRecord_status());
				session.setAttribute("contactperson",customer.getPrimary_contact_person());
				session.setAttribute("flag", customer.getActive_inactive_flag());
			    session.setAttribute("createdate",customer.getCreate_date());	
				session.setAttribute("createdby",customer.getCreated_by());
				RequestDispatcher dispacher = request.getRequestDispatcher("UpdateCustomerDetailsForm.jsp");
				dispacher.forward(request, response);
			} catch (SQLException e) {
				log.error("updatecustomerDetails method throws a SQL Exception");
			}
		}
		
		else if(button.equals("Update Details"))
		{
			String flagnew ="";
			String msg="";
			ValidationMethods validationmethods = new ValidationMethods();                             // Object of ValidationMethods class
			CheckValidations checkvalidationmethods = new CheckValidations(); 
			
			ICustomerService customerservice = new CustomerRDBMSImplService();
			HttpSession session = request.getSession(false);
			Date createdate = (Date) session.getAttribute("createdate");
			String createdby = (String) session.getAttribute("createdby");
			String status =(String) session.getAttribute("status");
			String userid = (String) session.getAttribute("userid");
			//String userid ="Priya12";
			String customercode = request.getParameter("customercode");
			
			String customername= request.getParameter("customername");
			
			String address1 = request.getParameter("address1");
			
			String address2 = request.getParameter("address2");
			
			int pincode = Integer.parseInt(request.getParameter("pincode"));
		
			String email = request.getParameter("email");
		
			long contactno = Long.parseLong(request.getParameter("contactno"));
			
			String contactperson = request.getParameter("contactperson");
			
			String flag = request.getParameter("flag");
			
			
			

			Customer customer = new Customer();
			customer.setCustomercode(customercode);
			customer.setCustomername(customername);
			customer.setAddress1(address1);
			customer.setAddress2(address2);
			customer.setCustomerpincode(pincode);
			customer.setEmailaddress(email);
			customer.setContactno(contactno);
			customer.setPrimary_contact_person(contactperson);
			customer.setRecord_status(status);
			customer.setActive_inactive_flag(flag);
			customer.setCreate_date(createdate);
			customer.setCreated_by(createdby);
			Date date = new Date();
			SimpleDateFormat smd = new SimpleDateFormat("dd/MMM/yyyy");
			String modifieddate = smd.format(date);
			try {
				customer.setModified_date(new SimpleDateFormat("dd/MMM/yyyy").parse(modifieddate));
			} catch (ParseException e1) {
				log.error("Date Realed Error in updatecustomerDetails1 method");
			}
			customer.setModified_by(userid);
			 boolean b = validationmethods.CheckCustomerName(customer.getCustomername());
			 if(b==true)
	         {
	        	 msg="Wrong Customer Name Inserted";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	         boolean c2 = validationmethods.CheckEmailAddress(customer.getEmailaddress());
	         if(c2==false)
	         {
	        	 msg="Wrong E-mail Inserted";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	         boolean d = validationmethods.CheckPincode(Integer.toString(customer.getCustomerpincode()));
	         if(d==true)
	         {
	        	 msg="Wrong Pincode Inserted";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	         boolean e = validationmethods.CheckRecordStatus(customer.getRecord_status());
	         if(e==false)
	         {
	        	 msg="Invalid RecordStatus";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	         boolean f = validationmethods.CheckFlag(customer.getActive_inactive_flag());
	         if(f==false)
	         {
	        	 msg="Invalid Flag";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	         boolean g = checkvalidationmethods.DataLength(customer);
	         if(g==false)
	         {
	        	 msg="Invalid DataLength";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	         boolean h = checkvalidationmethods.MandatoryFields(customer);  
	         if(h==false)
	         {
	        	 msg="Invalid MandatoryFields";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	         boolean i = checkvalidationmethods.DataType(customer);   
	         if(i==false)
	         {
	        	 msg="Invalid DataType";
	        	 session.setAttribute("msg", msg);
	        	 
	         }
	             
	         if(b==true||c2==false||d == true||e==false||f ==false||g==false||h==false||i==false)
	         {
	        	 flagnew = "1";
	        	 session.setAttribute("flagnew",flagnew);
	        	 /*RequestDispatcher dispacher = request.getRequestDispatcher("ValidationFailed.jsp");*/
	        	 RequestDispatcher dispacher = request.getRequestDispatcher("UpdateCustomerDetailsForm.jsp");
	        	 dispacher.forward(request, response);
	        	 
	         }
	         else
	         {
	        	 try {
					customerservice.updatecustomerDetails1(customer);
					log.info("updatecustomerDetails1 Method Called");
					RequestDispatcher dispacher = request.getRequestDispatcher("SuccessUpdateCustomerDetails.jsp");
		        	 dispacher.forward(request, response);
				} catch (SQLException e1) {
					log.error("updatecustomerDetails1 method throws a SQL Exception");
				}
	        	 
	         }

		}
		
		
		
		
	}

}
