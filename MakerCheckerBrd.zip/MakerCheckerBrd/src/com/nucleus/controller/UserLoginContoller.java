package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.nucleus.dao.IUserService;
import com.nucleus.dao.UserRDBMSImplService;
import com.nucleus.entity.User;

/**
 * Servlet implementation class UserLoginContoller
 */
@WebServlet("/UserLoginContoller")
public class UserLoginContoller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger log = Logger.getLogger(com.nucleus.controller.CustomerController.class);
    /**
     * Default constructor. 
     */
    public UserLoginContoller() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Hello");
		PrintWriter out = response.getWriter();
		String userid = request.getParameter("userid");
		System.out.println(userid);
		String password = request.getParameter("password");
		String role = request.getParameter("role");
		String value= request.getParameter("button");
		User user = new User();
		user.setUserId(userid);
		user.setPassword(password);
		user.setRole(role);
		//UserDao userdao = new UserRDBMSImpl();
		
		
		
		if(value.equals("Log In"))
		{
			if(role.equals("maker"))
			{
				
			IUserService userservice = new UserRDBMSImplService();
				try {
			User user1 = userservice.checkmakerlogindetails(user);
			String flag = user.getFlag();
			if(flag ==null)
			{
				HttpSession session = request.getSession();
				session.setAttribute("userid", userid);
				session.setAttribute("password", password);
				
				userservice.updatedetails(user1);
				log.info("updatedetails method Called");
				out.println("Login Successfully.................");
				RequestDispatcher requestdispacher = request.getRequestDispatcher("MakerFunctions.jsp");
				requestdispacher.forward(request,response);
			}
			
			else if(flag.equals("Active"))
			{
				request.setAttribute("flag", flag);
				RequestDispatcher rd = request.getRequestDispatcher("NotSuccess.jsp");
				rd.forward(request, response);
			}

		} catch (SQLException e) {
			log.error("checkmakerlogindetails method throws SQL Exception");
		}
		}
			else
			{
				RequestDispatcher rd = request.getRequestDispatcher("CheckerFunctions.jsp");
				rd.forward(request, response);
			}
		}
		  
	
		else if(value.equals("Register"))
		{
			IUserService userservice = new UserRDBMSImplService();
			try {
				
				userservice.insertcheckermakerlogindetails(user);
				log.info("insertcheckermakerlogindetails method Called");
				HttpSession session= request.getSession();
				session.setAttribute("userid", userid);
				RequestDispatcher requestdispacher = request.getRequestDispatcher("RegisterSuccessfully.jsp");
				requestdispacher.forward(request, response);
			} catch (SQLException e) {
				log.error("insertcheckermakerlogindetails method throws SQL Exception");
			}
		}
		
		
		else if(value.equals("3"))
		{
			
			IUserService userservice = new UserRDBMSImplService();
			HttpSession session = request.getSession(false);
			String userid1 = (String) session.getAttribute("userid");
			System.out.println(userid);
			try {
				
				userservice.logoutdetails(userid1);
				log.info("logoutdetails method Called");
				if(request.getSession(false)!=null)
				{
					session.invalidate();
					response.sendRedirect("MakerCheckerLogin.html");
				}
			} catch (SQLException e) {
				log.error("logoutdetails method throws SQL Exception");
			}
		}
	}

}