package com.nucleus.entity;

import java.io.Serializable;

public class User implements Serializable{
	
		
		private String UserId;
		private String Password;
		private String Role;
		private String Flag;
		public String getFlag() {
			return Flag;
		}
		public void setFlag(String flag) {
			Flag = flag;
		}
		public String getUserId() {
			return UserId;
		}
		public void setUserId(String userId) {
			UserId = userId;
		}
		public String getPassword() {
			return Password;
		}
		public void setPassword(String password) {
			Password = password;
		}
		public String getRole() {
			return Role;
		}
		public void setRole(String role) {
			Role = role;
		}
		
		

	

}
