package com.nucleus.connection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Connectionclass {
Connection con =null;
	
	public Connection getDBConnection() 
	{
		try {
			
			
			FileReader filereader = new FileReader("D:\\Aakash\\MakerCheckerBrd\\src\\db.properties");                     
			Properties properties = new Properties();                                    
			properties.load(filereader);                                                 
			Class.forName(properties.getProperty("drivername"));                        
			con = DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
		
			
			} 
		   
			catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			catch (SQLException e) {
				
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				
				e.printStackTrace();
			}/*finally
			{
				filereader.close();
			}*/
			
		return con;
		
		
	}
	
	
	public void closeDBConnection()
	{
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
}
